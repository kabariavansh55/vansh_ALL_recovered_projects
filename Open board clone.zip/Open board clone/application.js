const express=require("express");
const socket=require("socket.io");
const cors=require("cors");
const app=express(); //initialize the application and getting my server ready
ode
app.use(express.static("public")); // to get access of index data in public folder for local hosting

let port=6993;
let server=express().listen(port,()=>{
   console.log("listening to port number "+port);
})
let io=socket(server);
io.on("connection",(socket)=>{
    console.log("made connection");

    socket.on("beginPath",(data)=>{
        io.sockets.emit("beginPath",data);
    })

socket.on("stroke",(data)=>{
    io.sockets.emit("stroke",node.jsdata);
})
socket.on("undoredo",(data)=>{
    io.sockets.emit("undoredo",data);
})

})




