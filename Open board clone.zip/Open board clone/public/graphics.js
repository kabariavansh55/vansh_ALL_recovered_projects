let canvas=document.querySelector("canvas");
let scroll=document.querySelector(".scrollcontainer");
//using canvas API 
let access=canvas.getContext("2d");
let pencilColor=document.querySelectorAll(".pencil-color");
let pencilWidthElem=document.querySelector(".pencil-width");
let erasorWidthElem=document.querySelector(".erasor-width");
let download=document.querySelector(".download");
let undo=document.querySelector(".undo");
let redo=document.querySelector(".redo");
 let mouseDown=false;
 let penWidth=pencilWidthElem.value;
 let erasorWidth=erasorWidthElem.value;
let currcolor="red";
 access.strokeStyle =currcolor;
 access.lineWidth = "3";

 let undoRedoTracker=[];
 let tracker=0;

 //mouse down stimulate new path and move fill graphics
 canvas.addEventListener("mousedown",(e)=>{
    mouseDown=true;
    // beginPath({
    //     x:e.clientX,
    //     y:e.clientY
    // });
    let data={
        x:e.clientX,
        y:e.clientY
    }
    //send data to server
    socket.emit("beginPath",data);
 })
 


canvas.addEventListener("mousemove",(e)=>{
    
    if(mouseDown){
        let data={
            x:e.clientX,
            y:e.clientY,
            color:eraserFlag ? "white" : currcolor,
            width: eraserFlag ? erasorWidth :penWidth
        }
        socket.emit("stroke",data);
    }   
        // stroke({
        //     x:e.clientX,
        //     y:e.clientY,
        //     color:eraserFlag ? "white" : currcolor,
        //     width: eraserFlag ? erasorWidth :penWidth
        // });
    }
)


canvas.addEventListener("mouseup",(e)=>{
     mouseDown=false;
     let url=canvas.toDataURL();
     undoRedoTracker.push(url);
     tracker=undoRedoTracker.length-1;
 })
function beginPath(strokeObj){
    access.beginPath();
    access.moveTo(strokeObj.x,strokeObj.y); //client-x and client-y gives value of coordinates where mouse is clicked on!
}
function stroke(strokeObj){
    access.strokeStyle=strokeObj.color;
    access.lineWidth=strokeObj.width;
    access.lineTo(strokeObj.x,strokeObj.y);
    access.stroke();
}
pencilColor.forEach((colorElem)=>{
    colorElem.addEventListener("click",(e)=>{
        let color=colorElem.classList[0];
        currcolor=color;
        access.strokeStyle=currcolor;
    })
})
pencilWidthElem.addEventListener("change",(e)=>{
    penWidth=pencilWidthElem.value;
    access.lineWidth=penWidth;
})
erasorWidthElem.addEventListener("change",(e)=>{
    erasorWidth=erasorWidthElem.value;
    access.lineWidth=erasorWidth;
})
erasor.addEventListener("click",(e)=>{
    if(eraserFlag){
        access.strokeStyle="white";
        access.lineWidth=erasorWidth;
    }else{
        access.strokeStyle=currcolor;
        access.lineWidth=penWidth;
    }
})

download.addEventListener("click",(e)=>{
    let url=canvas.toDataURL();  // will convert canvas graphics pixels into a URL
    let anchor=document.createElement("a");
    anchor.href=url;
    anchor.download="One_Note.png";
    anchor.click();
})

undo.addEventListener("click",(e)=>{
   if(tracker>0){
       tracker--;
   }
//    let trackObj={
//        trackvalue:tracker,
//        undoRedoTracker
//    }
   let data={
    trackvalue:tracker,
    undoRedoTracker
}


socket.emit("undoredo",data);
//    undoRedoCanvas(trackObj);
})

redo.addEventListener("click",(e)=>{
    if(tracker < undoRedoTracker.length-1){
        tracker++;
    }
    // let trackObj={
    //     trackvalue:tracker,
    //     undoRedoTracker
    // }
    //socket ke liye 
    let data={
        trackvalue:tracker,
        undoRedoTracker
    }
    socket.emit("undoredo",data);
    // undoRedoCanvas(trackObj);
})

function undoRedoCanvas(trackObj){
    tracker=trackObj.trackvalue;
    undoRedoTracker=trackObj.undoRedoTracker;
    let url=undoRedoTracker[tracker];
    let img1 = new Image(); // new image reference by Image Class CoNSTRUCtor
    canvas.getContext("2d").clearRect(0,0,canvas.width,canvas.height);
    img1.src=url;
    img1.onload=(e)=>{
       access.drawImage(img1,0,0,canvas.width,canvas.height);
    }
}
socket.on("beginPath",(data)=>{
    // data-> data from server jo bhejega
    beginPath(data);
})
socket.on("stroke",(data)=>{
    stroke(data);
})

socket.on("undoredo",(data)=>{
   undoRedoCanvas(data);
})
