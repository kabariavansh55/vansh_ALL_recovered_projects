
let tool=document.querySelector(".tool-icon");
let allTools=document.querySelector(".tools");
let pencilToolContainer=document.querySelector(".pencil-tool-cont");
let eraserToolContainer=document.querySelector(".erasor-tool-cont");
let pencil=document.querySelector(".pencil");
let rec=document.querySelector(".rec")
let erasor=document.querySelector(".erasor");
let sticky=document.querySelector(".notes");
let upload=document.querySelector(".upload");
let video=document.querySelector(".video");
let changeback=document.querySelector(".switch");
let switchFlag=false;
let optionsFlag=true;
let pencilFlag=false;
let eraserFlag=false;


// Screen recording Iam Using Vanilla JavaScript here


rec.addEventListener("click",(e)=>{
    const start=async()=>{
        const stream=await navigator.mediaDevices.getDisplayMedia(
            {
                video:{
                    mediaDevices:"screen"
                },
                audio:{
                    mediaDevices:"syatemMicrophone"
                }
            }
        )
    const data=[];
    const mediaRecorder=new MediaRecorder(stream);

    mediaRecorder.ondataavailable=(e)=>{
        data.push(e.data);
    }
    mediaRecorder.start();
    mediaRecorder.onstop=(e)=>{
        data.push(e.data);
        let url=URL.createObjectURL(
            new Blob(data,{
                'type':'video/mp4',
            })
        )
        let anchor=document.createElement("a");
        anchor.href=url;
        anchor.download="screen_rec.mp4";
        anchor.click();
    }
    }
    start();
    
})

tool.addEventListener("click", (e) => {
   optionsFlag=!optionsFlag;
    if(optionsFlag) openTools();
    else closeTools();
})


function openTools(){
    let iconElem=tool.children[0];
    iconElem.classList.remove("fa-arrow-up-short-wide");
    iconElem.classList.add("fa-bars-staggered");
    allTools.style.display="flex";
}

function closeTools(){
    let iconElem=tool.children[0];
    iconElem.classList.remove("fa-bars-staggered");
    iconElem.classList.add("fa-arrow-up-short-wide");
    allTools.style.display="none";


    pencilToolContainer.style.display="none";
    eraserToolContainer.style.display="none";
}
pencil.addEventListener("click",(e)=>{
    pencilFlag=!pencilFlag;
    if(pencilFlag){
        pencilToolContainer.style.display="flex";
    }else pencilToolContainer.style.display="none";
})
erasor.addEventListener("click" ,(e)=>{
    eraserFlag=!eraserFlag;
    if(eraserFlag){
        eraserToolContainer.style.display="flex";
    }else eraserToolContainer.style.display="none";
})

video.addEventListener("click",(e)=>{
    let input=document.createElement("input");
    input.setAttribute("type","file");
    input.setAttribute("accept","video/*");

    input.click();
    input.addEventListener("change",(e)=>{
        let file=input.files[0];
        let url=URL.createObjectURL(file);
        const vid=document.createElement("div");
        vid.innerHTML=`
        <video width="420" height="220" controls="controls">
        <source src="${url}">
        </video>
        `
        document.body.appendChild(vid);
        vid.style.position="absolute";
    })
})


upload.addEventListener("click",(e)=>{
    //file uploading
    let input=document.createElement("input");
    input.setAttribute("type","file");
    input.click();

    input.addEventListener("change",(e)=>{
        let file=input.files[0];
        let url=URL.createObjectURL(file);
        let stickyTemplateHTML=`
        <div class="header-cont">
        <div class="min"></div>
        <div class="remove"></div>
        </div>
        <div class="note-cont">
        <img src="${url}" class="explorer"/>
        </div>
        `;
        createSticky(stickyTemplateHTML);
    })
})

sticky.addEventListener("click",(e)=>{
    let stickyTemplateHTML=`
    <div class="header-cont">
            <div class="min"></div>
            <div class="remove"></div>
        </div>
        <div class="note-cont">
            <textarea spellcheck="false"></textarea>
        </div>
    `;
    createSticky(stickyTemplateHTML);
})

function createSticky(stickyTemplateHTML){
    let stickyCont=document.createElement("div");
    stickyCont.setAttribute("class","notes-cont");
    stickyCont.innerHTML=stickyTemplateHTML;
 document.body.appendChild(stickyCont);
 stickyCont.style.position="absolute";
 let minimize=stickyCont.querySelector(".min");
 let remove=stickyCont.querySelector(".remove");
 sizeActions(minimize,remove,stickyCont);
 
 stickyCont.onmousedown = function(event){
     dragAndDrop(stickyCont,event);
 }
 stickyCont.ondragstart = function() {
     return false;
 };
 }

function sizeActions(minimize,remove,stickyCont){
   remove.addEventListener("click",(e)=>{
       stickyCont.remove();
   })
   minimize.addEventListener("click",(e)=>{
       let noteCont=stickyCont.querySelector(".note-cont");
       let display=getComputedStyle(noteCont).getPropertyValue("display");
       if(display==="none"){
           noteCont.style.display="block";
       }else{
           noteCont.style.display="none";
       }

   })
}
function dragAndDrop(element,event){
        let shiftX = event.clientX - element.getBoundingClientRect().left;
        let shiftY = event.clientY - element.getBoundingClientRect().top;
      
        element.style.position = 'absolute';
        element.style.zIndex = 1000;
      
        moveAt(event.pageX, event.pageY);
      
        // moves the element at (pageX, pageY) coordinates
        // taking initial shifts into account
        function moveAt(pageX, pageY) {
          element.style.left = pageX - shiftX + 'px';
          element.style.top = pageY - shiftY + 'px';
        }
      
        function onMouseMove(event) {
          moveAt(event.pageX, event.pageY);
        }
      
        // move the element on mousemove
        document.addEventListener('mousemove', onMouseMove);
      
        // drop the element, remove unneeded handlers
        element.onmouseup = function() {
          document.removeEventListener('mousemove', onMouseMove);
          element.onmouseup = null;
        };
      
      };

      changeback.addEventListener("click",(e)=>{
        switchFlag=!switchFlag;
        if(switchFlag){
            document.body.style.backgroundColor = "black";
            allTools.style.borderColor="yellow";
        }else{
            document.body.style.backgroundColor="white";
            allTools.style.borderColor="black";
        }
      })
      
      